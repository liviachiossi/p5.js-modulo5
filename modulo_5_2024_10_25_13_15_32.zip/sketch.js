function setup() {
  createCanvas(400, 400); // criando cenário 
}

function inicializaCores () {
  background('white'); // definindo a cor do fundo 
  fill ( 'black'); // definindo a cor da letra 
  textSize (64); // tamanho do texto 
  textAlign ( CENTER, CENTER); // centralização do texto 
   }


function draw() { // função do desenho 
  inicializaCores ();
  
  
  let maximo = width; // criando a variável "maximo" = largura
  let minimo = 0; // criando a variável "minimo" = 0
  // mouseX, 0, width ==> 0, palavra.length
  let palavra = "Caminhante"; // criando a variável palavra = "Caminhante"
  let quantidade = map (mouseX, 0, width, 1, palavra.length); // criando variável quantidade 
  // console.log (quantidade); 
  let parcial = palavra.substring (0, quantidade); // criando variável parcial 
  text(parcial, 200, 200); // tamanho do texto parcial 
  
}